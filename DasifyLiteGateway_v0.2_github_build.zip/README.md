# Dasify Lite Gateway v0.3 - diagnostic build

A lightweight Android SMS gateway for Android 6 / API 23+ and low-RAM devices.

## Included
- Seconds-based task polling.
- Seconds-based incoming-SMS upload.
- Persistent SQLite incoming/outgoing queues.
- Safe multi-message batch parsing: each server message is isolated and acknowledged independently.
- SMSSync-compatible task flow: GET `?task=send`, per-message POST `?task=sent` with `queued_messages`.
- Supports outgoing message identifiers `uuid`, `message_uuid`, and legacy `id`.
- Android SmsManager sending, including multipart SMS.
- Per-part send-result tracking and 30-second result wait before retry.
- Exponential retry backoff up to 5 minutes.
- Incoming SMS are stored before upload.
- Start on boot, configurable in UI.
- START_STICKY service and foreground notification on Android 8+.
- Diagnostic status panel showing task/upload/error states.
- Test Connection button.
- Persistent debug log with Copy Debug Log button.
- No third-party runtime libraries.

## Important behavior
The app does not crash on a malformed batch entry. It records the problem and continues with the next entry.

For incoming upload, any HTTP 2xx response is accepted unless a JSON payload explicitly contains `success:false`.

For task fetching, malformed JSON, non-2xx HTTP responses, and connection errors are shown in the diagnostic panel and the persistent log.

## GitHub build
The supplied workflow uses GitHub Actions with JDK 17, Android SDK, and Gradle. The workflow can extract a single uploaded ZIP so the project can be uploaded from a phone without uploading folders.

## Server compatibility
The task download and queued-message acknowledgement follow the SMSSync protocol documentation. Server implementations may differ in their exact JSON fields; this build accepts common `uuid`, `message_uuid`, and `id` outgoing identifiers.
