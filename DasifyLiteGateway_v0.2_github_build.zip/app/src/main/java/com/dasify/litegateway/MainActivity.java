package com.dasify.litegateway;

import android.app.*;
import android.os.*;
import android.content.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    EditText url,secret,device,task,upload,retry;
    public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout l=new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL); l.setPadding(24,24,24,24);
        url=e("Server URL"); secret=e("Secret"); device=e("Device ID");
        task=e("Task check interval (seconds)"); upload=e("SMS upload interval (seconds)"); retry=e("SMS retry base (seconds)");
        task.setText("5"); upload.setText("5"); retry.setText("5");
        l.addView(url);l.addView(secret);l.addView(device);l.addView(task);l.addView(upload);l.addView(retry);
        Button start=new Button(this); start.setText("SAVE + START");
        Button stop=new Button(this); stop.setText("STOP");
        l.addView(start); l.addView(stop); setContentView(l);
        if(Build.VERSION.SDK_INT>=23)
            requestPermissions(new String[]{"android.permission.RECEIVE_SMS","android.permission.READ_SMS","android.permission.SEND_SMS"},77);
        start.setOnClickListener(v->{save();startService(new Intent(this,GatewayService.class));});
        stop.setOnClickListener(v->stopService(new Intent(this,GatewayService.class)));
        load();
    }
    EditText e(String h){ EditText x=new EditText(this);x.setHint(h);x.setSingleLine(true);return x; }
    void load(){
        android.content.SharedPreferences p=getSharedPreferences("cfg",0);
        url.setText(p.getString("url","")); secret.setText(p.getString("secret","")); device.setText(p.getString("device","android"));
        task.setText(String.valueOf(Math.max(1,p.getLong("task_ms",5000)/1000)));
        upload.setText(String.valueOf(Math.max(1,p.getLong("upload_ms",5000)/1000)));
        retry.setText(String.valueOf(Math.max(1,p.getLong("send_retry_ms",5000)/1000)));
    }
    void save(){
        long t=sec(task.getText().toString(),5), u=sec(upload.getText().toString(),5), r=sec(retry.getText().toString(),5);
        getSharedPreferences("cfg",0).edit()
            .putString("url",url.getText().toString().trim())
            .putString("secret",secret.getText().toString())
            .putString("device",device.getText().toString().trim())
            .putLong("task_ms",t*1000L)
            .putLong("upload_ms",u*1000L)
            .putLong("send_retry_ms",r*1000L).apply();
    }
    long sec(String s,long d){try{return Math.max(1,Long.parseLong(s));}catch(Exception e){return d;}}
}
