package com.dasify.litegateway;

import android.content.*;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) return;

        android.content.SharedPreferences p=c.getSharedPreferences("cfg",0);
        boolean auto=p.getBoolean("auto_start",true);
        String url=p.getString("url","").trim();

        // Start automatically after boot. If configuration is incomplete,
        // GatewayService remains idle until the user saves valid settings.
        if (auto) c.startService(new Intent(c,GatewayService.class));
    }
}
