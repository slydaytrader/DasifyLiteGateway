package com.dasify.litegateway;
import android.content.*;
public class BootReceiver extends BroadcastReceiver{
    public void onReceive(Context c,Intent i){
        if(Intent.ACTION_BOOT_COMPLETED.equals(i.getAction()) && c.getSharedPreferences("cfg",0).getBoolean("auto_start",true)){
            try{c.startService(new Intent(c,GatewayService.class));}catch(Exception e){Log.write(c,"ERROR","boot start: "+e);}
        }
    }
}
