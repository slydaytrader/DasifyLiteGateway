package com.dasify.litegateway;
import android.content.*;import android.os.*;import android.telephony.SmsMessage;
public class SmsReceiver extends BroadcastReceiver{
 public void onReceive(Context c,Intent i){
  try{Bundle b=i.getExtras();if(b==null)return;Object[]pdus=(Object[])b.get("pdus");if(pdus==null)return;String fmt=b.getString("format");String sender=null;StringBuilder body=new StringBuilder();long when=System.currentTimeMillis();
   for(Object p:pdus){SmsMessage m=(Build.VERSION.SDK_INT>=23)?SmsMessage.createFromPdu((byte[])p,fmt):SmsMessage.createFromPdu((byte[])p);if(sender==null)sender=m.getOriginatingAddress();body.append(m.getMessageBody());when=Math.max(when,m.getTimestampMillis());}
   String id=sender+"-"+when+"-"+body.length();new Db(c).addIncoming(id,sender==null?"":sender,body.toString(),when);State.set(c,"RUNNING","","SMS received","-");Log.write(c,"INFO","SMS received from "+sender+" len="+body.length());c.startService(new Intent(c,GatewayService.class));
  }catch(Exception e){Log.write(c,"ERROR","SMS receive: "+e);State.set(c,"ERROR","","","SMS receive: "+e);}
 }
}
