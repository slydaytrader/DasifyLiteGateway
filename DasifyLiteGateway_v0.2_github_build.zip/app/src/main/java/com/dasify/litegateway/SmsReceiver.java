package com.dasify.litegateway;

import android.content.*;
import android.os.*;
import android.telephony.SmsMessage;

public class SmsReceiver extends BroadcastReceiver {
    public void onReceive(Context c, Intent i){
        try{
            Bundle b=i.getExtras(); if(b==null)return;
            Object[] pdus=(Object[])b.get("pdus"); if(pdus==null)return;
            String fmt=b.getString("format");
            String sender=null; StringBuilder body=new StringBuilder(); long when=System.currentTimeMillis();
            String firstId=null;
            for(Object p:pdus){
                SmsMessage m;
                if(Build.VERSION.SDK_INT>=23)m=SmsMessage.createFromPdu((byte[])p,fmt);
                else m=SmsMessage.createFromPdu((byte[])p);
                if(sender==null)sender=m.getOriginatingAddress();
                body.append(m.getMessageBody());
                when=Math.max(when,m.getTimestampMillis());
                if(firstId==null) firstId=String.valueOf(m.getTimestampMillis())+"-"+sender+"-"+body.length();
            }
            if(firstId!=null) new Db(c).addIncoming(firstId,sender,body.toString(),when);
            c.startService(new Intent(c,GatewayService.class));
        }catch(Exception ignored){}
    }
}
