package com.dasify.litegateway;

import android.content.Context;
import android.content.SharedPreferences;

final class State {
    private static final String P = "runtime";
    static void set(Context c, String status, String task, String upload, String error) {
        SharedPreferences p=c.getSharedPreferences(P,0);
        p.edit().putString("status",status).putString("task",task).putString("upload",upload)
            .putString("error",error==null?"":error).putLong("at",System.currentTimeMillis()).apply();
    }
    static String get(Context c,String k,String d){ return c.getSharedPreferences(P,0).getString(k,d); }
    static long at(Context c){ return c.getSharedPreferences(P,0).getLong("at",0); }
}
