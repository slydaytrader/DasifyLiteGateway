package com.dasify.litegateway;
import android.content.*;
import java.util.concurrent.ConcurrentHashMap;

public class SmsSendResultReceiver extends BroadcastReceiver {
    static final ConcurrentHashMap<String,Result> RESULTS=new ConcurrentHashMap<String,Result>();
    public static final class Result{public final boolean sent;public final int code;Result(boolean s,int c){sent=s;code=c;}}
    public void onReceive(Context c,Intent i){String token=i.getStringExtra("token");if(token==null)return;RESULTS.put(token,new Result(getResultCode()==android.app.Activity.RESULT_OK,getResultCode()));}
}
