package com.dasify.litegateway;

import android.content.*;
import java.util.concurrent.ConcurrentHashMap;

public class SmsSendResultReceiver extends BroadcastReceiver {
    static final String ACTION_SENT = "com.dasify.litegateway.SMS_SENT";
    static final String ACTION_DELIVERED = "com.dasify.litegateway.SMS_DELIVERED";
    static final ConcurrentHashMap<String, Result> RESULTS = new ConcurrentHashMap<>();

    public static final class Result {
        public final boolean sent;
        public final int code;
        Result(boolean sent, int code) { this.sent = sent; this.code = code; }
    }

    @Override public void onReceive(Context c, Intent i) {
        String uuid = i.getStringExtra("uuid");
        if (uuid == null) return;
        boolean ok = getResultCode() == android.app.Activity.RESULT_OK;
        RESULTS.put(uuid, new Result(ok, getResultCode()));
    }
}
