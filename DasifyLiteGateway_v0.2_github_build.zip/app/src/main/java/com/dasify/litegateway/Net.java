package com.dasify.litegateway;

import java.io.*;
import java.net.*;
import java.net.URLEncoder;
import java.util.*;

final class Net {
    static String request(String method, String url, String body, Map<String,String> form, int timeout) throws Exception {
        if (form != null && !form.isEmpty()) {
            StringBuilder b = new StringBuilder();
            for (Map.Entry<String,String> e : form.entrySet()) {
                if (b.length() > 0) b.append('&');
                b.append(URLEncoder.encode(e.getKey(),"UTF-8")).append('=')
                 .append(URLEncoder.encode(e.getValue() == null ? "" : e.getValue(),"UTF-8"));
            }
            body = b.toString();
        }
        HttpURLConnection c = (HttpURLConnection)new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(timeout);
        c.setReadTimeout(timeout);
        c.setUseCaches(false);
        c.setDoInput(true);
        c.setRequestProperty("Cache-Control","no-cache");
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type",
                form != null ? "application/x-www-form-urlencoded; charset=UTF-8" :
                "application/json; charset=UTF-8");
            OutputStream o = c.getOutputStream();
            o.write(body.getBytes("UTF-8"));
            o.close();
        }
        int code = c.getResponseCode();
        InputStream in = (code >= 200 && code < 400) ? c.getInputStream() : c.getErrorStream();
        StringBuilder out = new StringBuilder();
        if (in != null) {
            BufferedReader r = new BufferedReader(new InputStreamReader(in,"UTF-8"));
            String line;
            while ((line = r.readLine()) != null) out.append(line);
            r.close();
        }
        c.disconnect();
        if (code < 200 || code >= 300) throw new IOException("HTTP " + code);
        return out.toString();
    }
}
