package com.dasify.litegateway;

import android.content.Context;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

final class Log {
    private static final String FILE = "debug.log";
    private static final int MAX = 90000;
    private static final SimpleDateFormat FMT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US);

    static synchronized void write(Context c, String level, String msg) {
        try {
            File f = new File(c.getFilesDir(), FILE);
            FileOutputStream out = new FileOutputStream(f, true);
            String line = FMT.format(new Date()) + " " + level + " " + msg + "\n";
            out.write(line.getBytes("UTF-8")); out.close();
            if (f.length() > MAX) trim(f);
        } catch (Exception ignored) {}
    }

    static synchronized String tail(Context c, int maxChars) {
        try {
            File f = new File(c.getFilesDir(), FILE);
            if (!f.exists()) return "No log yet.";
            RandomAccessFile r = new RandomAccessFile(f, "r");
            long start = Math.max(0, r.length() - maxChars);
            r.seek(start);
            byte[] b = new byte[(int)(r.length() - start)];
            r.readFully(b); r.close();
            return new String(b, "UTF-8");
        } catch (Exception e) { return "Log read error: " + e; }
    }

    private static void trim(File f) {
        try {
            RandomAccessFile r = new RandomAccessFile(f, "r");
            long start = Math.max(0, r.length() - 60000);
            r.seek(start);
            byte[] b = new byte[(int)(r.length()-start)];
            r.readFully(b); r.close();
            FileOutputStream out = new FileOutputStream(f,false);
            out.write(b); out.close();
        } catch (Exception ignored) {}
    }
}
