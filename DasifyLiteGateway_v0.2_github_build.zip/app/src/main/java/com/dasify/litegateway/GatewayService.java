package com.dasify.litegateway;

import android.app.*;
import android.content.*;
import android.os.*;
import android.telephony.SmsManager;
import android.database.Cursor;
import java.util.*;
import org.json.*;

public class GatewayService extends Service {
    private Handler h;
    private Db db;
    private volatile boolean running;
    private String base, secret, device;
    private long taskMs, uploadMs, sendRetryMs;
    private Thread taskThread, uploadThread;

    private final Runnable taskLoop = new Runnable() {
        public void run() {
            if (!running) return;
            taskOnce();
            h.postDelayed(this, taskMs);
        }
    };

    private final Runnable uploadLoop = new Runnable() {
        public void run() {
            if (!running) return;
            uploadOnce();
            h.postDelayed(this, uploadMs);
        }
    };

    @Override public int onStartCommand(Intent i, int flags, int startId) {
        if (running) return START_STICKY;
        running = true;
        db = new Db(this);
        h = new Handler(Looper.getMainLooper());
        load();
        h.postDelayed(taskLoop, 1000);
        h.postDelayed(uploadLoop, 1000);
        h.postDelayed(sendLoop, 1000);
        return START_STICKY;
    }

    private void load() {
        android.content.SharedPreferences p = getSharedPreferences("cfg",0);
        base = p.getString("url","").trim();
        secret = p.getString("secret","");
        device = p.getString("device","android");
        taskMs = Math.max(1000, p.getLong("task_ms",5000));
        uploadMs = Math.max(1000, p.getLong("upload_ms",5000));
        sendRetryMs = Math.max(2000, p.getLong("send_retry_ms",5000));
    }

    private String endpoint(String task) {
        return base + (base.contains("?") ? "&" : "?") + "task=" + task;
    }

    private void taskOnce() {
        if (base.length() == 0) return;
        if (taskThread != null && taskThread.isAlive()) return;
        taskThread = new Thread(new Runnable() {
            public void run() {
                try {
                    String u = endpoint("send");
                    if (secret.length() > 0) u += "&secret=" + java.net.URLEncoder.encode(secret,"UTF-8");
                    String s = Net.request("GET", u, null, null, 12000);
                    JSONObject root = new JSONObject(s);
                    JSONObject p = root.optJSONObject("payload");
                    if (p == null || !"send".equalsIgnoreCase(p.optString("task"))) return;
                    JSONArray a = p.optJSONArray("messages");
                    if (a == null) return;
                    JSONArray ack = new JSONArray();
                    for (int x=0; x<a.length(); x++) {
                        try {
                            JSONObject m = a.optJSONObject(x);
                            if (m == null) continue;
                            String uuid=m.optString("uuid"), to=m.optString("to"), msg=m.optString("message");
                            if (uuid.length()==0 || to.length()==0) continue;
                            db.addOutgoing(uuid,to,msg);
                            ack.put(uuid);
                        } catch (Exception ignored) {}
                    }
                    if (ack.length()>0) {
                        // Keep a simple acknowledgement body; server-compatible clients may accept this.
                        JSONObject j = new JSONObject();
                        j.put("queued_messages", ack);
                        try { Net.request("POST", endpoint("sent"), j.toString(), null, 12000); }
                        catch (Exception ignored) {}
                    }
                } catch (Exception ignored) {}
            }
        });
        taskThread.start();
    }

    private void uploadOnce() {
        if (base.length() == 0) return;
        if (uploadThread != null && uploadThread.isAlive()) return;
        uploadThread = new Thread(new Runnable() {
            public void run() {
                Cursor c = null;
                try {
                    c = db.pendingIncoming(10);
                    while (running && c.moveToNext()) {
                        long id=c.getLong(0);
                        int tries=c.getInt(5);
                        if (tries >= 8) continue;
                        HashMap<String,String> f=new HashMap<>();
                        f.put("from",c.getString(2));
                        f.put("message",c.getString(3));
                        f.put("message_id",c.getString(1));
                        f.put("device_id",device);
                        f.put("sent_timestamp",String.valueOf(c.getLong(4)/1000));
                        f.put("sent_to","");
                        if (secret.length()>0) f.put("secret",secret);
                        try {
                            String r=Net.request("POST",base,null,f,12000);
                            JSONObject o=new JSONObject(r);
                            JSONObject p=o.optJSONObject("payload");
                            boolean ok = p != null &&
                                (p.optBoolean("success",false) || "true".equalsIgnoreCase(p.optString("success")));
                            if (ok) db.markIncoming(id,1,tries,nullSafe());
                            else db.markIncoming(id,0,tries+1,nextRetry(tries));
                        } catch(Exception e) {
                            db.markIncoming(id,0,tries+1,nextRetry(tries));
                        }
                    }
                } catch(Exception ignored) {} finally { if(c!=null)c.close(); }
            }
        });
        uploadThread.start();
    }

    private void sendOneOutgoing() {
        Cursor c=null;
        try {
            c=db.pendingOutgoing(System.currentTimeMillis());
            if(!c.moveToFirst()) return;
            final String uuid=c.getString(0), dest=c.getString(1), body=c.getString(2);
            final int tries=c.getInt(3);
            SmsManager sms=SmsManager.getDefault();
            Intent sentIntent=new Intent(this,SmsSendResultReceiver.class)
                .setAction(SmsSendResultReceiver.ACTION_SENT)
                .putExtra("uuid",uuid);
            PendingIntent pi=PendingIntent.getBroadcast(this, stableCode(uuid),
                sentIntent, pendingFlags());

            sms.sendTextMessage(dest,null,body,pi,null);

            // Give the modem stack a brief window to post the result; if no result arrives,
            // the row remains retryable rather than being deleted.
            final long deadline=System.currentTimeMillis()+15000;
            h.postDelayed(new Runnable(){ public void run(){
                SmsSendResultReceiver.Result r=SmsSendResultReceiver.RESULTS.remove(uuid);
                if(r!=null && r.sent) {
                    db.markOutgoing(uuid,1,tries,null,System.currentTimeMillis());
                } else if (r!=null) {
                    db.markOutgoing(uuid,0,tries+1,"send_result_"+r.code,nextRetry(tries));
                } else if(System.currentTimeMillis()>=deadline) {
                    db.markOutgoing(uuid,0,tries+1,"no_result",nextRetry(tries));
                }
            }},15000);
        } catch(Exception e) {
            if(c!=null && c.moveToFirst()) {
                String uuid=c.getString(0); int tries=c.getInt(3);
                db.markOutgoing(uuid,0,tries+1,e.getClass().getSimpleName(),nextRetry(tries));
            }
        } finally { if(c!=null)c.close(); }
    }

    private static int stableCode(String s){ return Math.abs(s.hashCode() & 0x7fffffff); }
    private static int pendingFlags(){ return Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_UPDATE_CURRENT | 0x04000000 : PendingIntent.FLAG_UPDATE_CURRENT; }
    private long nullSafe(){ return System.currentTimeMillis(); }
    private long nextRetry(int tries){
        long n=Math.min(60000L, 3000L * (long)Math.max(1, tries+1));
        return System.currentTimeMillis()+Math.max(sendRetryMs,n);
    }

    private final Runnable sendLoop = new Runnable() {
        public void run() {
            if (!running) return;
            sendOneOutgoing();
            h.postDelayed(this, 1000);
        }
    };

    @Override public void onDestroy(){
        running=false;
        if(h!=null){ h.removeCallbacks(taskLoop); h.removeCallbacks(uploadLoop); h.removeCallbacks(sendLoop); }
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent i){ return null; }
}
