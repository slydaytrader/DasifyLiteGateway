package com.dasify.litegateway;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;

final class Db extends SQLiteOpenHelper {
    private static final String DB="gateway.db";
    Db(Context c){super(c,DB,null,3);}
    public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE incoming(id INTEGER PRIMARY KEY AUTOINCREMENT,sms_id TEXT UNIQUE,sender TEXT,body TEXT,sent_at INTEGER,state INTEGER DEFAULT 0,tries INTEGER DEFAULT 0,updated INTEGER)");
        d.execSQL("CREATE TABLE outgoing(uuid TEXT PRIMARY KEY,dest TEXT,body TEXT,state INTEGER DEFAULT 0,tries INTEGER DEFAULT 0,updated INTEGER,last_error TEXT)");
        d.execSQL("CREATE INDEX incoming_state ON incoming(state,updated)");
        d.execSQL("CREATE INDEX outgoing_state ON outgoing(state,updated)");
    }
    public void onUpgrade(SQLiteDatabase d,int oldV,int newV){
        if(oldV<2){try{d.execSQL("ALTER TABLE incoming ADD COLUMN tries INTEGER DEFAULT 0");}catch(Exception ignored){} try{d.execSQL("ALTER TABLE incoming ADD COLUMN updated INTEGER");}catch(Exception ignored){} try{d.execSQL("ALTER TABLE outgoing ADD COLUMN last_error TEXT");}catch(Exception ignored){}}
    }
    synchronized long addIncoming(String smsId,String sender,String body,long sentAt){
        ContentValues v=new ContentValues();v.put("sms_id",smsId);v.put("sender",sender);v.put("body",body);v.put("sent_at",sentAt);v.put("updated",System.currentTimeMillis());
        try{return getWritableDatabase().insertOrThrow("incoming",null,v);}catch(Exception e){return -1;}
    }
    synchronized void addOutgoing(String uuid,String dest,String body){
        ContentValues v=new ContentValues();v.put("uuid",uuid);v.put("dest",dest);v.put("body",body);v.put("updated",System.currentTimeMillis());
        getWritableDatabase().insertWithOnConflict("outgoing",null,v,SQLiteDatabase.CONFLICT_IGNORE);
    }
    synchronized Cursor pendingIncoming(int limit,long now){
        return getReadableDatabase().rawQuery("SELECT id,sms_id,sender,body,sent_at,tries FROM incoming WHERE state=0 AND (updated IS NULL OR updated<=?) ORDER BY id LIMIT "+limit,new String[]{String.valueOf(now)});
    }
    synchronized Cursor pendingOutgoing(long now){
        return getReadableDatabase().rawQuery("SELECT uuid,dest,body,tries FROM outgoing WHERE state=0 AND (updated IS NULL OR updated<=?) ORDER BY updated LIMIT 1",new String[]{String.valueOf(now)});
    }
    synchronized int count(String table,int state){
        Cursor c=null;try{c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table+" WHERE state=?",new String[]{String.valueOf(state)});return c.moveToFirst()?c.getInt(0):0;}finally{if(c!=null)c.close();}}
    synchronized void markIncoming(long id,int state,int tries,long next){ContentValues v=new ContentValues();v.put("state",state);v.put("tries",tries);v.put("updated",next);getWritableDatabase().update("incoming",v,"id=?",new String[]{String.valueOf(id)});}
    synchronized void markOutgoing(String uuid,int state,int tries,String err,long next){ContentValues v=new ContentValues();v.put("state",state);v.put("tries",tries);v.put("updated",next);v.put("last_error",err);getWritableDatabase().update("outgoing",v,"uuid=?",new String[]{uuid});}
}
